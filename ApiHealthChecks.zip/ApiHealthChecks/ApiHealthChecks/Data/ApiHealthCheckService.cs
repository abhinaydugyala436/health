﻿namespace ApiHealthChecks.Data
{
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;
    public class ApiHealthStatus
    {
        public int Id { get; set; }
        public string Url { get; set; }
        public string Health { get; set; }
        public bool IsSuccess { get; set; }
        public string Verb { get; set; }
    }
    public class ApiUrl
    {
        public string Url { get; set; }
        public string Verb { get; set; }
        public string Payload { get; set; }
    };
    public class ApiHealthCheckService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration configuration;

        public ApiHealthCheckService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            this.configuration = configuration;
        }

        public async Task<ApiHealthStatus> IsApiHealthyAsync(ApiUrl apiUrl)
        {
            try
            {
                HttpResponseMessage response = null;
                switch (apiUrl.Verb)
                {
                    case "Get":
                        response = await _httpClient.GetAsync(apiUrl.Url);

                        break;
                    case "Post":
                        response = await _httpClient.PostAsync(apiUrl.Url, new StringContent(apiUrl.Payload));

                        break;
                    case "Put":
                        response = await _httpClient.PutAsync(apiUrl.Url, new StringContent(apiUrl.Payload));
                        break;
                    case "Delete":
                        response = await _httpClient.DeleteAsync(apiUrl.Url);
                        break;
                }
                response.EnsureSuccessStatusCode();

                return new ApiHealthStatus() { Url = apiUrl.Url, Verb = apiUrl.Verb, IsSuccess = true, Health = "Healthy" };
            }
            catch
            {
                return new ApiHealthStatus() { Url = apiUrl.Url, Verb = apiUrl.Verb, IsSuccess = false, Health = "UnHealthy" };
            }
        }

        public async Task<List<ApiHealthStatus>> GetHealth()
        {
            var apiUrls = new List<ApiUrl>();
            configuration.GetSection("HealthCheckApiList").Bind(apiUrls);

            List<ApiHealthStatus> healthStatuses = new List<ApiHealthStatus>();
            foreach (var apiUrl in apiUrls)
            {
                var apiHealthStatus = await IsApiHealthyAsync(apiUrl);
                healthStatuses.Add(apiHealthStatus);
            }
            return healthStatuses;
        }
    }

}
